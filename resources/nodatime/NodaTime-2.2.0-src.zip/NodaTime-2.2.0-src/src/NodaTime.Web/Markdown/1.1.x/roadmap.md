@Title="Current roadmap"

Our online Developer Guide contains [an _approximate_ roadmap][roadmap] for the
major features that we hope to support in Noda Time, some of which are inspired
by Noda Time's [current limitations](limitations).

[roadmap]: /developer/roadmap

If there's something not mentioned there that you feel should be on the
roadmap, then *please* either raise an issue or post on the
[mailing list](https://groups.google.com/group/noda-time).
