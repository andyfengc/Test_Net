@Title="Version history"

The version history is now a [site-wide page](/versions) rather than
being maintained on a per-version-user-guide basis.
