@Title="Overview"

This is a guide to developing Noda Time itself. If you are developing
_with_ Noda Time, see the [User Guide][] instead.

Resources
---------

- [Project source and issue site][home]
- [Group mailing list][group]
- [Current API documentation][api]

[User Guide]: /userguide/
[home]: https://github.com/nodatime/nodatime
[group]: https://groups.google.com/group/noda-time
[api]: /unstable/api/
