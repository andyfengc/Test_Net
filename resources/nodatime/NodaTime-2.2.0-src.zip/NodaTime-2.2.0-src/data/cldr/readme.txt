Note that the file format for Windows mappings changed around CLDR 2.0.1
to include a territory ID. Earlier versions have been removed as no longer
being valid for the code base which now expects the more complete mapping
information.
