Noda Time is a better .NET date and time API.

Project web site:   http://nodatime.org
Group/mailing list: http://groups.google.com/group/noda-time

Project source and issue site: https://github.com/nodatime/nodatime

Please note that as of v2.0, the serialization packages are
distributed separately from this zip file, and only via NuGet.
